import 'package:crud_api/consts/secret.dart';
import 'package:crud_api/routes/auth/auth_route.dart';
import 'package:crud_api/routes/upload/upload_route.dart';
import 'package:crud_api/routes/users/users_route.dart';
import 'package:crud_api/shared/supabase_helper.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf_router/shelf_router.dart';
import 'package:shelf/shelf_io.dart' as io;

void main(List<String> arguments) async {
  final supabase = SupabaseHelper.instance;

  final connection = PostgreSQLConnection(
    host,
    port,
    database,
    username: username,
    password: password,
    useSSL: true,
  );

  await connection.open().then((_) => print('PostgreSQL Connected'));

  final router = Router();

  router.mount('/upload/', UploadService(connection).router);

  router.mount('/auth/', AuthService(connection).router);

  router.mount('/users/', UsersService(connection).router);

  await io.serve(router, '0.0.0.0', 5000).then((server) {
    final url = 'http://${server.address.host}:${server.port}';
    return print('Server running at $url');
  }).catchError((e) {
    return print(e);
  });
}
