const host = 'ec2-3-234-22-132.compute-1.amazonaws.com';
const database = 'd49vkf9oua059h';
const username = 'juwlctcehprxfo';
const port = 5432;
const password =
    '4424bc5a372ac1f30c7b1e6fd42fbad650064a6c2b95ec31c617033d56b2f402';

const supabaseUrl = 'https://khlbvfzuagmrxpjbqqzu.supabase.co';
const supabaseKey =
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJyb2xlIjoiYW5vbiIsImlhdCI6MTYzNTAzMjQ3MCwiZXhwIjoxOTUwNjA4NDcwfQ.lVZZAGlh7LTuPhYL_J7afRm2nqO7ZDKkRJybs9f8enQ';
