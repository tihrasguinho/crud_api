import 'dart:async';

import 'package:crud_api/routes/auth/routes/refresh_route.dart';
import 'package:crud_api/routes/auth/routes/signin_route.dart';
import 'package:crud_api/routes/auth/routes/signup_route.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

part 'auth_route.g.dart';

class AuthService {
  final PostgreSQLConnection connection;

  AuthService(this.connection);

  @Route.post('/signin')
  FutureOr<Response> signIn(Request req) => signInRoute(req, connection);

  @Route.post('/signup')
  FutureOr<Response> signUp(Request req) => signUpRoute(req, connection);

  @Route.post('/refresh')
  FutureOr<Response> refresh(Request req) => refreshRoute(req, connection);

  Router get router => _$AuthServiceRouter(this);
}
