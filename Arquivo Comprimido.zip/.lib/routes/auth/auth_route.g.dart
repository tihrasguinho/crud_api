// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'auth_route.dart';

// **************************************************************************
// ShelfRouterGenerator
// **************************************************************************

Router _$AuthServiceRouter(AuthService service) {
  final router = Router();
  router.add('POST', r'/signin', service.signIn);
  router.add('POST', r'/signup', service.signUp);
  router.add('POST', r'/refresh', service.refresh);
  return router;
}
