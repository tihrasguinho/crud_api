import 'dart:convert';

import 'package:crud_api/shared/jwt_helper.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';

Future<Response> refreshRoute(
  Request req,
  PostgreSQLConnection connection,
) async {
  print('${req.method} => ${req.requestedUri}');

  var payload = checkRefreshToken(req);

  if (!payload.containsKey('error')) {
    var uid = payload['uid'];

    var query = await connection.mappedResultsQuery(
      'select * from users where uid = @uid',
      substitutionValues: {'uid': uid},
    );

    if (query.isEmpty) {
      return Response(
        404,
        body: jsonEncode({'message': 'user token not valid'}),
      );
    } else {
      var accessToken = createAccessToken(uid);

      return Response(200, body: jsonEncode({'access_token': accessToken}));
    }
  } else {
    return Response(400, body: jsonEncode({'message': payload['error']}));
  }
}
