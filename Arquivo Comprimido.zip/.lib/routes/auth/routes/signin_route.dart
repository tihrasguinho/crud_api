import 'dart:convert';

import 'package:crud_api/routes/auth/utils/auth_helpers.dart';
import 'package:crud_api/shared/jwt_helper.dart';
import 'package:crud_api/routes/auth/utils/auth_password.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';

Future<Response> signInRoute(
  Request req,
  PostgreSQLConnection connection,
) async {
  print('${req.method} => ${req.requestedUri}');

  final body = jsonDecode(await req.readAsString()) as Map;

  if (signinDataCheck(body)) {
    var query = await connection.mappedResultsQuery(
      'select * from users where email = @email',
      substitutionValues: {'email': body['email']},
    );

    if (query.isEmpty) {
      return Response(404, body: jsonEncode({'message': 'user not found'}));
    } else {
      var data = query.first['users'] as Map;

      var passwordHashed = hashPassword(body['password']);

      if (passwordHashed == data['password']) {
        var accessToken = createAccessToken(data['uid']);

        var refreshToken = createRefreshToken(data['uid']);

        data.remove('password');

        data['access_token'] = accessToken;

        data['refresh_token'] = refreshToken;

        return Response(200, body: jsonEncode(data));
      } else {
        return Response(400, body: jsonEncode({'message': 'wrong password'}));
      }
    }
  } else {
    return Response(
      400,
      body: jsonEncode({'message': 'user data not provided'}),
    );
  }
}
