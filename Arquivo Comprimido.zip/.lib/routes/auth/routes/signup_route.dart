import 'dart:convert';

import 'package:crud_api/routes/auth/utils/auth_helpers.dart';
import 'package:crud_api/routes/auth/utils/auth_password.dart';
import 'package:crud_api/shared/jwt_helper.dart';
import 'package:crud_api/shared/supabase_helper.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';

Future<Response> signUpRoute(
  Request req,
  PostgreSQLConnection connection,
) async {
  print('${req.method} => ${req.requestedUri}');

  final body = jsonDecode(await req.readAsString()) as Map;

  if (isUserValid(body)) {
    try {
      var password = hashPassword(body['password']);

      final client = SupabaseHelper.instance.client;

      var supaIns = await client.from('users').insert({
        'name': body['name'],
        'email': body['email'],
        'password': password,
        'image': '',
      }).execute();

      print(supaIns.data);

      var insert = await connection.mappedResultsQuery(
        'insert into users(name, email, password) values (@name, @email, @password) returning *',
        substitutionValues: {
          'name': body['name'],
          'email': body['email'],
          'password': password,
        },
      );

      var data = insert.first['users'] as Map;

      var accessToken = createAccessToken(data['uid']);

      var refreshToken = createRefreshToken(data['uid']);

      data.remove('password');

      data['access_token'] = accessToken;

      data['refresh_token'] = refreshToken;

      return Response(200, body: jsonEncode(data));
    } on PostgreSQLException catch (e) {
      return Response(
        400,
        body: jsonEncode({'message': e.detail}),
      );
    } on Exception catch (e) {
      return Response(
        400,
        body: jsonEncode({'message': e.toString()}),
      );
    }
  } else {
    return Response(
      400,
      body: jsonEncode({'message': 'user data not provided'}),
    );
  }
}
