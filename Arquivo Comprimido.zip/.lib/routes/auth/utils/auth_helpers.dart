bool isUserValid(Map map) =>
    map.containsKey('name') &&
    map.containsKey('email') &&
    map.containsKey('password');

bool signinDataCheck(Map map) =>
    map.containsKey('email') && map.containsKey('password');
