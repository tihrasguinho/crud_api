import 'dart:convert';

import 'package:crypto/crypto.dart';

String hashPassword(String password) {
  var key = utf8.encode('PASSWORD_HASH');
  var hash = utf8.encode(password);

  var hmac = Hmac(sha256, key);
  var digest = hmac.convert(hash);

  return digest.toString();
}
