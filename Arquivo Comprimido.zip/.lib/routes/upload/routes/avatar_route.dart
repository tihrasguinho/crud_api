import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:crud_api/shared/jwt_helper.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf_multipart/form_data.dart';

Future<Response> avatarRoute(
  Request req,
  PostgreSQLConnection connection,
) async {
  print('${req.method} => ${req.requestedUri}');

  final payload = checkAccessToken(req);

  if (!payload.containsKey('error')) {
    if (req.isMultipartForm) {
      final parameters = {
        await for (final form in req.multipartFormData)
          form.name: await form.part.readBytes(),
      };

      if (parameters.containsKey('image')) {
        final bytes = parameters['image'] as Uint8List;
        final filename = '${DateTime.now().millisecondsSinceEpoch}-IMAGE.JPEG';
        final file = File('./uploads/$filename');

        await file.writeAsBytes(bytes);

        await connection.mappedResultsQuery(
          'update users set image = @url, updated_at = (extract(epoch from now()) * 1000) where uid = @uid',
          substitutionValues: {
            'url':
                'http://Users/tihrasguinho/dart-projs/crud_api/uploads/$filename',
            'uid': payload['uid'],
          },
        );

        return Response(200, body: jsonEncode({'message': 'image updated'}));
      } else {
        return Response(400,
            body: jsonEncode({'message': 'image not provided'}));
      }
    } else {
      return Response(200);
    }
  } else {
    return Response(400, body: jsonEncode({'message': payload['error']}));
  }
}
