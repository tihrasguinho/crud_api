import 'dart:async';

import 'package:crud_api/routes/upload/routes/avatar_route.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

part 'upload_route.g.dart';

class UploadService {
  final PostgreSQLConnection connection;

  UploadService(this.connection);

  @Route.post('/avatar')
  FutureOr<Response> avatar(Request req) => avatarRoute(req, connection);

  Router get router => _$UploadServiceRouter(this);
}
