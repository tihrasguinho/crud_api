// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'upload_route.dart';

// **************************************************************************
// ShelfRouterGenerator
// **************************************************************************

Router _$UploadServiceRouter(UploadService service) {
  final router = Router();
  router.add('POST', r'/avatar', service.avatar);
  return router;
}
