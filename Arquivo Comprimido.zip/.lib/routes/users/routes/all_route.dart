import 'dart:convert';

import 'package:crud_api/shared/jwt_helper.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';

Future<Response> allUsersRoute(
  Request req,
  PostgreSQLConnection connection,
) async {
  print('${req.method} => ${req.requestedUri}');

  var payload = checkAccessToken(req);

  if (!payload.containsKey('error')) {
    var query = await connection.mappedResultsQuery(
      'select uid, name, email, image, created_at from users where uid != @uid',
      substitutionValues: {'uid': payload['uid']},
    );

    var users = query.map((e) => e['users']).toList();

    return Response(
      200,
      body: jsonEncode({'users': users}),
    );
  } else {
    return Response(400, body: jsonEncode({'message': payload['error']}));
  }
}
