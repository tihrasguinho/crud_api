import 'dart:convert';

import 'package:crud_api/shared/jwt_helper.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';

Future<Response> oneUserRoute(
  Request req,
  String uid,
  PostgreSQLConnection connection,
) async {
  print('${req.method} => ${req.requestedUri}');

  var payload = checkAccessToken(req);

  if (!payload.containsKey('error')) {
    var query = await connection.mappedResultsQuery(
      'select uid, name, email, image, created_at from users where uid = @uid',
      substitutionValues: {'uid': uid},
    );

    if (query.isNotEmpty) {
      return Response(200, body: jsonEncode({'user': query.first['users']}));
    } else {
      return Response(404, body: jsonEncode({'message': 'user not found'}));
    }
  } else {
    return Response(400, body: jsonEncode({'message': payload['error']}));
  }
}
