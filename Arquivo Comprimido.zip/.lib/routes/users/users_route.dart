import 'dart:async';

import 'package:crud_api/routes/users/routes/all_route.dart';
import 'package:crud_api/routes/users/routes/me_route.dart';
import 'package:crud_api/routes/users/routes/one_route.dart';
import 'package:postgres/postgres.dart';
import 'package:shelf/shelf.dart';
import 'package:shelf_router/shelf_router.dart';

part 'users_route.g.dart';

class UsersService {
  final PostgreSQLConnection connection;

  UsersService(
    this.connection,
  );

  @Route.get('/all')
  FutureOr<Response> all(Request req) => allUsersRoute(req, connection);

  @Route.get('/one/<uid>')
  FutureOr<Response> one(Request req, String uid) =>
      oneUserRoute(req, uid, connection);

  @Route.get('/me')
  FutureOr<Response> me(Request req) => meRoute(req, connection);

  Router get router => _$UsersServiceRouter(this);
}
