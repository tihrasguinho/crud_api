// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'users_route.dart';

// **************************************************************************
// ShelfRouterGenerator
// **************************************************************************

Router _$UsersServiceRouter(UsersService service) {
  final router = Router();
  router.add('GET', r'/all', service.all);
  router.add('GET', r'/one/<uid>', service.one);
  router.add('GET', r'/me', service.me);
  return router;
}
