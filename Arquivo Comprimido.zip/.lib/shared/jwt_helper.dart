import 'package:dart_jsonwebtoken/dart_jsonwebtoken.dart';
import 'package:shelf/shelf.dart';

String createAccessToken(String uid) {
  var jwt = JWT({'uid': uid, 'issuer': 'dev.tihrasguinho'});

  var accessToken = jwt.sign(
    SecretKey('ACCESS_TOKEN_HASH'),
    expiresIn: Duration(hours: 1),
  );

  return accessToken;
}

String createRefreshToken(String uid) {
  var jwt = JWT({'uid': uid, 'issuer': 'dev.tihrasguinho'});

  var accessToken = jwt.sign(
    SecretKey('REFRESH_TOKEN_HASH'),
    expiresIn: Duration(days: 7),
  );

  return accessToken;
}

Map checkAccessToken(Request req) {
  try {
    var token = req.headers['authorization'];

    if (token == null) return {'error': 'jwt not provided'};

    var refreshToken = token.split(' ').last;

    final jwt = JWT.verify(refreshToken, SecretKey('ACCESS_TOKEN_HASH'));

    return jwt.payload;
  } on JWTExpiredError {
    return {'error': 'jwt expired'};
  } on JWTError catch (ex) {
    return {'error': ex.message};
  }
}

Map checkRefreshToken(Request req) {
  try {
    var token = req.headers['authorization'];

    var refreshToken = token!.split(' ').last;

    final jwt = JWT.verify(refreshToken, SecretKey('REFRESH_TOKEN_HASH'));

    return jwt.payload;
  } on JWTExpiredError {
    return {'error': 'jwt expired'};
  } on JWTError catch (ex) {
    return {'error': ex.message};
  }
}
