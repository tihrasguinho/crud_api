import 'package:crud_api/consts/secret.dart';
import 'package:supabase/supabase.dart';

class SupabaseHelper {
  SupabaseHelper._privateConstructor();

  static final SupabaseHelper _instance = SupabaseHelper._privateConstructor();

  static SupabaseHelper get instance => _instance;

  SupabaseClient get client => SupabaseClient(supabaseUrl, supabaseKey);
}
